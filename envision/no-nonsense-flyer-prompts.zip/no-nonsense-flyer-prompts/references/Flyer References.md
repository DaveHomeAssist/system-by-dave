# Flyer References

Pick a reference that matches the event series and the job of the graphic. These are visual observations from the public No Nonsense flyer set plus the Off the Hook draft. Use the approved copy for the current edition when filling in titles, billing, dates, or venue wording. Follow an attached reference when Nick supplies one.

## Pick a starting point

| When Nick asks for… | Look at… | Put this in the prompt |
| --- | --- | --- |
| **An AfterJinx save the date** | [AfterJinx 2026 teaser](https://nononsensephilly.com/media/flyers/afterjinx-2026-card.webp) | Deep blue and black, a quiet water texture, one octopus silhouette off to the side, and generous dark space for the title and date. |
| **An AfterJinx lineup reveal** | [AfterJinx 2025](https://nononsensephilly.com/media/flyers/afterjinx-2025-card.webp) | Saturated tentacle forms framing a darker center. Keep a large headliner zone, tiers for support, and a separate details footer. |
| **An AfterBreak mystery bill** | [AfterBreak 2025](https://nononsensephilly.com/media/flyers/afterbreak-2025-card.webp) and [2026](https://nononsensephilly.com/media/flyers/afterbreak-2026-card.webp) | A dark ground, abrasive edges, and an obvious space for a big question mark graphic. Keep the support rows and public location wording easy to find. |
| **An Endpoint Connections edition** | [Endpoint 1.0](https://nononsensephilly.com/media/flyers/endpoint-connections-1-card.webp) and [2.0](https://nononsensephilly.com/media/flyers/endpoint-connections-2-card.webp) | A bright geometric axis, symmetrical circuit or laser lines, and dark zones behind artist marks. Shift the accent color or intensity to distinguish the edition. |
| **An artist-led show** | [Justin Hawkes](https://nononsensephilly.com/media/flyers/justin-hawkes-2026-card.webp) | Make the approved artist photo the focal point. The reference uses warm light and metallic shapes around the portrait, with billing stacked below. |
| **A playful illustrated world** | [Kandi Island](https://nononsensephilly.com/media/flyers/kandi-island-2025-card.webp), [Park Rave 005](https://nononsensephilly.com/media/flyers/park-rave-005-2026-card.webp), and Off the Hook draft | Choose an event-specific hook. Kandi Island uses beaded type and palms. Park Rave uses a psychedelic bicycle scene and comic bursts. Off the Hook uses an oversized, thick-outlined fish and a big title and date. |
| **An FAQ story** | AfterJinx FAQ story copy | Carry over one small campaign motif. Build a dark, low-detail text area for a question and a short answer. Give dates, hours, and location their own slides when that clarifies the message. |

Use the supplied No Nonsense wordmark for placement. For a new event series, borrow useful composition or texture from the closest reference and give the event its own subject.

## Worked examples

### AfterJinx · a lineup reveal with billing still open

**Nick says**

> AfterJinx lineup drop. More tentacles around the edges. I’m still waiting on the final lineup.

**Image prompt**

```text
Create a 4:5 artwork plate for an underground bass afterparty flyer.
Frame the edges with curled deep-sea tentacles with hot orange
highlights against black and inky teal. Keep the top center clear
for a supplied event title. Leave a wide dark zone below it for one
headliner mark and a calm middle area for rows of support marks.
Keep the bottom low-detail for the event information. Artwork only,
without lettering or logos.
```

**Placement**  
Top: No Nonsense wordmark and supplied AfterJinx title. Middle: headliner and support marks. Footer: approved night/date, hours, public venue wording, age, and CTA.  
**Confirm**  
Final billing and event copy before layout.

### AfterBreak · keep the layout, change the temperature

**Nick says**

> Make this icier. Same layout and mystery headliner. Need a story too.

**Edit prompt**

```text
Shift the background accents to ice blue and cool chrome. Keep
the black base, existing title, question mark, artist marks,
billing order, and footer in place. Apply the new color to the
background linework and edge texture. Keep contrast behind the
artist marks and text.
```

**Story adjustment**  
Rebuild at 9:16. Keep the mystery mark near the top, stack support marks in the middle, and pull the date and CTA inward so interface overlays leave them visible. Use the same approved copy and supplied files.

### Justin Hawkes · use a supplied portrait

**Nick says**

> Use the Justin Hawkes flyer for layout. I have an approved artist photo. Make this one warm and smoky.

**Image prompt**

```text
Create a 4:5 background for a portrait-led drum and bass flyer.
Reserve a centered chest-up silhouette area for the supplied cutout.
Wrap smoke, curved metallic shapes, and warm amber rim light around
the portrait zone. Fade the lower third to dark charcoal for the
headliner and support billing. Keep an open band near the bottom
for event details. Artwork only, without faces, lettering, or logos.
```

**Placement**  
Add the supplied photo at center. Put the headliner directly below the portrait, followed by the supplied support marks and the event details.

## Format notes

- **4:5 feed** keeps the title, focal image, and first billing tier visible at thumbnail size. Use a clearly defined footer.
- **9:16 story** gives the layout more height. Reflow the billing or split a dense announcement across slides. Keep key text clear of top and bottom interface overlays.
- **4 × 6 in print** is a 2:3 trim ratio. Confirm the printer's bleed and safe area, extend edge artwork through the bleed, and keep type and any real QR code inside the safe area.
- **FAQ story** uses editable type over a simple plate. Keep one answer per slide and verify midnight date wording against current event copy.
