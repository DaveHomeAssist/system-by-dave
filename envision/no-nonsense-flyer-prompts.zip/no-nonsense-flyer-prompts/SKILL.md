---
name: no-nonsense-flyer-prompts
description: Draft paste-ready image generation and edit prompts for No Nonsense Collective event flyers, teasers, lineup reveals, artist cards, stories, and print variants. Use when Nick supplies an event idea, past No Nonsense flyer, or existing graphic and wants a prompt or a targeted revision.
---

# No Nonsense Flyer Prompts

Turn Nick's rough direction into one ready-to-paste prompt and a short layout handoff. Start drafting as soon as the request gives you enough to choose a visual direction.

## Read the brief

Use the current event or series, asset type, and any attached art, copy, or notes. Read [Flyer References](references/Flyer%20References.md) when selecting a house reference, interpreting a series name, or adapting a format. A reference gives you composition and visual cues. Nick's current instructions control the new design.

Ask one focused question if an unresolved choice would materially change the artwork. For a missing lineup, time, or venue, draft the background with flexible space for the detail and flag it outside the image prompt. If the asset or format is unspecified, assume a 4:5 feed flyer and label the assumption.

## Draft the prompt

- Choose a single visual idea for the event. Describe the focal subject, palette, linework or texture, placement, and the areas that need lower detail for copy. Use two or three specific cues from the chosen reference.
- Match the requested asset. A teaser needs room for the event title and one action. A lineup reveal needs a headliner zone, a support zone, and a detail footer. An FAQ story should carry one answer per slide. For additional formats, give the layout changes for each. Give a standalone prompt for each format if Nick requests one.
- Default to artwork only. Describe empty space for the actual text and logos. Use supplied brand files and artist marks in layout. For a portrait-led design, tell the generator how to integrate the supplied photo or reserve space for it. For a finished mockup with baked-in lettering, quote only the exact short text Nick requests, then put the remaining copy in the placement list.
- Use plain language that works across image tools. Add model-specific syntax only when Nick names a tool and the syntax is relevant. Draft prompts by default. Generate an image only when Nick asks for it.

## Keep event details accurate

Use approved copy for this edition. Preserve spellings and billing order, including any b2b notation. Mark uncertain fields as missing in the handoff and keep them out of generated lettering. When times cross midnight, check how the advertised event night maps to the calendar date. Follow the current brief's disclosure level for artist reveals and secret locations. When sources disagree, flag the specific conflict and keep drafting the art.

## Return the result

1. **Image prompt.** One copyable block for the primary asset.
2. **Copy and placement.** List confirmed text and supplied assets by zone. Include empty slots only where the design needs them.
3. **Format changes.** Include this when Nick asks for additional crops, print, or story.
4. **Confirm.** Include this only for material assumptions, missing details, or conflicts.

On an edit request, return the revised prompt or a short edit instruction suited to the supplied image. State the change and preserve any layout, copy, logos, or proportions Nick did not ask to change. If he asks for prompt only, return the prompt block alone.
